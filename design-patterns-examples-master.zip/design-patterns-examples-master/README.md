# Design Patterns Examples

Examples about Design Patterns to UNISATC Software Engineering

Patterns Criacionais:

- Factory Method
- Abstract Factory
- Builder
- Singleton

Patterns Estruturais:

- Adapter
- Bridge
- Composite
- Decorator