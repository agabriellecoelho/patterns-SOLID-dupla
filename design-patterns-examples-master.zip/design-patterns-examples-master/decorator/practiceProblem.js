class MessagePrinter {
  print(text) {
    console.log(text);
  }
}

const printer = new MessagePrinter();
printer.print("Olá, mundo!");
